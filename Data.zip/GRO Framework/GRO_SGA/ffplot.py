import numpy as np
import matplotlib.pyplot as plt
import math
import glob
import os
import pandas as pd
import statistics 
data = []
#################
path = "./FF/10indf"
all_files = glob.glob(os.path.join(path, "*.csv")) 
sum = 0
i = 1
dfn = []
result = []
for file in all_files:
    file_name = os.path.splitext(os.path.basename(file))[0]
    #print (file_name)
    dfn = pd.read_csv(file)
    list = dfn.to_numpy()
    c = 0
    for i in range(len(list)):
        c += 1
        if int(list[i][1]) != 0:
            result.append(math.log(float(list[i][3]), 2) - math.log(200, 2))
            break
data.append(result)
x = statistics.mean(result) 
print("FF 10indf Mean is :", x) 
################
path = "./FF/1100"
all_files = glob.glob(os.path.join(path, "*.csv")) 
sum = 0
i = 1
dfn = []
result = []
for file in all_files:
    file_name = os.path.splitext(os.path.basename(file))[0]
    #print (file_name)
    dfn = pd.read_csv(file)
    list = dfn.to_numpy()
    c = 0
    for i in range(len(list)):
        c += 1
        if int(list[i][1]) != 0:
            result.append(math.log(float(list[i][3]), 2) - math.log(200, 2))
            break
data.append(result)
x = statistics.mean(result) 
print("FF 1100 Mean is :", x) 
################
path = "./FF/11000"
all_files = glob.glob(os.path.join(path, "*.csv")) 
sum = 0
i = 1
dfn = []
result = []
for file in all_files:
    file_name = os.path.splitext(os.path.basename(file))[0]
    #print (file_name)
    dfn = pd.read_csv(file)
    list = dfn.to_numpy()
    c = 0
    for i in range(len(list)):
        c += 1
        if int(list[i][1]) != 0:
            result.append(math.log(float(list[i][3]), 2) - math.log(200, 2))
            break
data.append(result)
x = statistics.mean(result) 
print("FF 11000 Mean is :", x) 
#############
path = "./FF/11111"
all_files = glob.glob(os.path.join(path, "*.csv")) 
sum = 0
i = 1
dfn = []
result = []
for file in all_files:
    file_name = os.path.splitext(os.path.basename(file))[0]
    #print (file_name)
    dfn = pd.read_csv(file)
    list = dfn.to_numpy()
    c = 0
    for i in range(len(list)):
        c += 1
        if int(list[i][1]) != 0:
            result.append(math.log(float(list[i][5]), 2) - math.log(200, 2))
            break
data.append(result)
x = statistics.mean(result) 
print("FF 11111 Mean is :", x) 
################




fig1, axs = plt.subplots()
axs.set_title('SGA GRO Fitness Function')
plt.xticks([1,2,3,4], ['FF(10indef)','FF(1100)', 'FF(11000)', 'FF(11111)'], rotation=45, fontsize=8)
axs.set_ylabel('First GFP')
arr = np.array(data)
axs.boxplot(data)
axs.set_ylim(0, 22)
plt.show()


#axes = df1.boxplot(column='Gross_Margin',layout=(1,9), figsize=(20,10),
#                   whis=[5,95], return_type='axes')
#for ax in axes.values():
#    ax.set_ylim(-2.5, 2.5)

#plt.show()