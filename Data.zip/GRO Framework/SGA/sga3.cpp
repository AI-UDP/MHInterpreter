#include <iostream>
#include <vector>
#include <algorithm>
#include <utility>
#include <random>
#include <fstream>
#include <string>

using namespace std;

typedef vector<int> vctr;
typedef pair<int, vctr> individual;
typedef vector<individual> pop;

const int POP_SIZE = 10000;//Tamaño de la poblacion
const double MUT_RATE = 0.1;//Rate de mutaciones
const int CROSS_RATE = 4;//Rate de crossover
const int GEN_SIZE = 5;//Tamaño del gen(target)
const int MAX_IT = 100;//Numero de iteraciones
const int N_EXPERIMENTS = 30; // Numero de csv's a generar
const int TARGET[] {1,1,0,0,2};//Combinacion buscada

void print_population(pop &population){ 
    vctr count(GEN_SIZE);
    for(int i(0); i < POP_SIZE; ++i){
        ++count[population[i].first];
    }

    cout<<count[0]<<'\n';
}
int fitness_evaluation(vctr &v){
    int c(0);
    for(int i(0); i < GEN_SIZE; ++i){
        if(TARGET[i] == 2) continue;
        if(v[i] != TARGET[i]) c++;
    }
    return c;
}
int rnd_int(int lo, int hi){
    random_device rd; mt19937 e(rd());
    static uniform_int_distribution<> dis(lo, hi);
    return dis(e);
}
float rnd_float(float lo, float hi){
    random_device rd; mt19937 e(rd());
    static uniform_real_distribution<> dis(lo, hi);
    return dis(e);
}
void mutate_gen(vctr &v){
    int index(rnd_int(0, GEN_SIZE - 1));
    if (v[index] == 1) v[index] = 0;
    else v[index] = 1;
}
void crossover(vctr &p1, vctr &p2, vctr &offspring){
    for(int i(0); i < GEN_SIZE; ++i){
        float dice = rnd_float(0, 1);
        if (dice < 0.5) offspring[i] = p1[i];
        else offspring[i] = p2[i];
    }
}
void new_generation(pop &population){
    pop auxpop;
    int best_fraction = ((POP_SIZE-CROSS_RATE) * POP_SIZE) / POP_SIZE;
    for(int i(0); i < best_fraction; ++i){
        auxpop.push_back(population[i]);
    }
    int c(0);
    int fittest_individual = ((POP_SIZE- CROSS_RATE) * POP_SIZE) / POP_SIZE;
    int cross_fraction = (CROSS_RATE) * POP_SIZE / POP_SIZE;
    for(int i(0); i < cross_fraction; ++i){
        int index1 = rnd_int(0, fittest_individual);
        int index2 = rnd_int(0, fittest_individual);
        vctr offspring(GEN_SIZE, 0);
        crossover(population[index1].second, population[index2].second, offspring);
        float dice = rnd_float(0,1);
        if (dice < MUT_RATE){
            mutate_gen(offspring);
        }
        int f_value = fitness_evaluation(offspring);
        if(f_value == 0) c++;
        auxpop.push_back(make_pair(f_value, offspring));
    }
    population = auxpop;
}
int main() {
    pop population(POP_SIZE);
    int c(0);
    for(int i(0); i < POP_SIZE; ++i){
        vctr v(GEN_SIZE);
        v[rnd_int(0, GEN_SIZE - 1)] = 1;
        int f_value = fitness_evaluation(v);
        if (f_value == 0) c++;
        population[i] = make_pair(f_value, v);
    }
    print_population(population);
    for(int i = 0; i < 20; ++i){
        new_generation(population);
        sort(population.begin(), population.end()); 
        print_population(population);
    }
    cout<<1<<'\n';
    return 0;
}