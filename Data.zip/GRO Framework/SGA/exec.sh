#!/bin/bash
z="N/10000"
w="out"
for j in {1..30}; do
    touch $z/$w$j".csv"
    ./sga > $z/$w$j".csv"
done