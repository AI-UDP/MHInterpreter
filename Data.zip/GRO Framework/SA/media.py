import glob
import os
import pandas as pd
import math
import numpy as np
path = "./FF/10indf"
all_files = glob.glob(os.path.join(path, "*.csv")) 
sum = 0
print(path)
for file in all_files:
    file_name = os.path.splitext(os.path.basename(file))[0]
    dfn = pd.read_csv(file)
    c = 0
    #media
    list = dfn.to_numpy()
    for i in range(len(list)):
        if list[i][1] == 1:
            break
        c += 1
    sum += c
sum /= 30.0
print(sum)
    