import numpy as np
import matplotlib.pyplot as plt
import math
# Fixing random state for reproducibility
import glob
import os
import pandas as pd

data = []
path = "./T/25"
all_files = glob.glob(os.path.join(path, "*.csv")) 
sum = 0
i = 1
dfn = []
result = []
for file in all_files:
    file_name = os.path.splitext(os.path.basename(file))[0]
    #print (file_name)
    dfn = pd.read_csv(file)
    list = dfn.to_numpy()
    c = 0
    for i in range(len(list)):
        if list[i][1] == 1:
            result.append(c)
            break
        c += 1
data.append(result)
path = "./T/50"
all_files = glob.glob(os.path.join(path, "*.csv")) 
sum = 0
i = 1
dfn = []
result = []
for file in all_files:
    file_name = os.path.splitext(os.path.basename(file))[0]
    dfn = pd.read_csv(file)
    list = dfn.to_numpy()
    c = 0
    for i in range(len(list)):
        if list[i][1] == 1:
            result.append(c)
            break
        c += 1
data.append(result)
path = "./T/75"
all_files = glob.glob(os.path.join(path, "*.csv")) 
sum = 0
i = 1
dfn = []
result = []
for file in all_files:
    file_name = os.path.splitext(os.path.basename(file))[0]
    dfn = pd.read_csv(file)
    list = dfn.to_numpy()
    c = 0
    for i in range(len(list)):
        if list[i][1] == 1:
            result.append(c)
            break
        c += 1
data.append(result)
path = "./T/90"
all_files = glob.glob(os.path.join(path, "*.csv")) 
sum = 0
i = 1
dfn = []
result = []
for file in all_files:
    file_name = os.path.splitext(os.path.basename(file))[0]
    dfn = pd.read_csv(file)
    list = dfn.to_numpy()
    c = 0
    for i in range(len(list)):
        if list[i][1] == 1:
            result.append(c)
            break
        c += 1
data.append(result)
fig1, axs = plt.subplots()
axs.set_title('SA C Temperature')
arr = np.array(data)
axs.boxplot(data)
plt.show()