#!/bin/bash
i=1
z="10indf"
w="out"
for filename in input/*.txt; do 
    for j in {1..30}; do
        touch "FF"/$z/$w$j".csv"
        ./sa $(cat $filename) > "FF"/$z/$w$j".csv"
    done
    ((i++))
done